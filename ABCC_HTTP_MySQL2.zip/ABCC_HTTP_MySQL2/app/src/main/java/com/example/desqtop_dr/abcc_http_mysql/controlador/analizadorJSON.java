package com.example.desqtop_dr.abcc_http_mysql.controlador;

import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Map;

public class analizadorJSON {
    InputStream is=null;
    JSONObject jsonObject=null;
    String json =null;
    OutputStream os=null;

    public JSONObject peticionHTTP(String url, String metodo, String dato){

        HttpURLConnection conexion = null;
        URL mUrl = null;

        try {
            String cadenaJSON = "{\"c\":\""+ URLEncoder.encode(dato,"UTF-8")+"\"}";
            mUrl = new URL(url);
            conexion =(HttpURLConnection) mUrl.openConnection();

            conexion.setDoOutput(true);
            conexion.setRequestMethod(metodo);
            conexion.setFixedLengthStreamingMode(cadenaJSON.getBytes().length);
            conexion.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
            OutputStream os = new BufferedOutputStream(conexion.getOutputStream());

            os.write(cadenaJSON.getBytes());
            os.flush();
            os.close();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            is =  new BufferedInputStream(conexion.getInputStream());
            BufferedReader br =  new BufferedReader(new InputStreamReader(is));
            StringBuilder cad = new StringBuilder();

            String fila;
            while ((fila = br.readLine()) != null){
                cad.append(fila+"\n");
            }
            is.close();
            json = cad.toString();
        }catch (UnsupportedEncodingException e){
            e.printStackTrace();
        }catch (IOException e){
            e.printStackTrace();
        }

        try {
            jsonObject = new JSONObject(json);
        }catch (JSONException e){
            e.printStackTrace();
        }

        return jsonObject;
    }
}


