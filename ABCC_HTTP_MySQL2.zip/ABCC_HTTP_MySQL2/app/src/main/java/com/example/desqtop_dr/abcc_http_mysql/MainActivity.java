package com.example.desqtop_dr.abcc_http_mysql;

import android.os.AsyncTask;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioGroup;

import com.example.desqtop_dr.abcc_http_mysql.controlador.analizadorJSON;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listViewAlumnos;
    ArrayAdapter<String> adaptador;
    EditText cajaConsulta;

    ArrayList<String> arrayList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listViewAlumnos = findViewById(R.id.listView_FiltradoAlumno);
        cajaConsulta=findViewById(R.id.editText_FiltradoCarrera);

        final MostrarAlumnosConFiltro mACF = new MostrarAlumnosConFiltro();
        adaptador = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);

        RadioGroup radioGroup = findViewById(R.id.radio_Group);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                switch (i){
                    case R.id.radioButton_IIA:
                        mACF.execute();
                        listViewAlumnos.setAdapter(adaptador);
                        break;
                    case R.id.radioButton_IM:
                        mACF.execute();
                        listViewAlumnos.setAdapter(adaptador);
                        break;
                    case R.id.radioButton_ISC:
                        mACF.execute();
                        listViewAlumnos.setAdapter(adaptador);
                        break;
                    case R.id.radioButton_LA:
                        mACF.execute();
                        listViewAlumnos.setAdapter(adaptador);
                        break;
                    case R.id.radioButton_LC:
                        mACF.execute();
                        listViewAlumnos.setAdapter(adaptador);
                        break;
                }
            }
        });
    }
    class MostrarAlumnosConFiltro extends AsyncTask<String,String,String>{

        protected String doInBackground(String... strings) {
            String dato= "isc";

            analizadorJSON analizadorJSON = new analizadorJSON();
            String url="http://192.168.1.76/Programacion WEB II/HTTP_Android/consulta_alumnos_filtro.php";

            JSONObject jsonObject= analizadorJSON.peticionHTTP(url,"POST", dato);
            try {
                JSONArray jsonArray= jsonObject.getJSONArray("alumnos");

                for (int i=0; i<jsonArray.length(); i++){
                    String datos = jsonArray.getJSONObject(i).getString("nc")+"-"+
                            jsonArray.getJSONObject(i).getString("n")+"-"+
                            jsonArray.getJSONObject(i).getString("pa")+"-"+
                            jsonArray.getJSONObject(i).getString("sa")+"-"+
                            jsonArray.getJSONObject(i).getString("e")+"-"+
                            jsonArray.getJSONObject(i).getString("s")+"-"+
                            jsonArray.getJSONObject(i).getString("c");

                    arrayList.add(datos);
                }
            }catch (JSONException e){
                e.printStackTrace();
            }
            return null;
        }
    }
}
